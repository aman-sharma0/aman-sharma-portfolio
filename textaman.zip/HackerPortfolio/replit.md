# textAman Terminal Portfolio

## Overview

textAman is an interactive terminal-style portfolio website for Aman Sharma, a cybersecurity professional specializing in penetration testing, red teaming, and security engineering. The project features an authentic terminal interface with command-driven navigation, ASCII art loading screens, and a dark cybersecurity aesthetic. Built as a full-stack application with React frontend and Express backend, it showcases professional experience, skills, certifications, and contact information through an immersive terminal experience.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
The frontend is built using React with TypeScript, implementing a single-page application (SPA) architecture. The design follows a terminal-inspired UI pattern using:

- **Component Structure**: Modular React components including `ASCIILoader` for initial boot sequence, `TerminalWindow` for main interface, and comprehensive UI component library from shadcn/ui
- **Styling System**: Tailwind CSS with custom terminal color scheme featuring pure black background, matrix green prompts, and monospace fonts (Fira Code primary)
- **State Management**: React hooks for local state, with potential for React Query integration for server state
- **Routing**: Wouter for lightweight client-side routing
- **Build System**: Vite for fast development and optimized production builds

### Backend Architecture
Express.js server with TypeScript providing:

- **API Structure**: RESTful endpoints with `/api` prefix convention
- **Middleware Stack**: JSON parsing, URL encoding, request logging, and error handling
- **Storage Interface**: Abstracted storage layer with in-memory implementation (MemStorage) and interface for future database integration
- **Development Integration**: Vite middleware integration for seamless development experience

### Database Design
Currently implements in-memory storage with plans for PostgreSQL integration:

- **Schema Definition**: Drizzle ORM with TypeScript schemas for type safety
- **User Model**: Basic user structure with ID, username, and password fields
- **Migration Strategy**: Drizzle Kit for schema migrations and database management
- **Connection**: Neon Database serverless PostgreSQL configured but not actively used

### Authentication & Security
Prepared for authentication implementation with:

- **Session Management**: Express sessions with potential PostgreSQL store integration
- **Password Security**: Prepared for secure password hashing
- **API Security**: CORS and security headers ready for implementation

### Design System
Custom terminal aesthetic with:

- **Color Palette**: Dark mode exclusive with terminal-authentic colors (pure black background, matrix green accents, red errors, yellow warnings)
- **Typography**: Monospace fonts for authentic terminal feel
- **Interactive Elements**: Command-based navigation, typewriter effects, blinking cursor animations
- **Responsive Design**: Mobile-first approach maintaining terminal authenticity across devices

## External Dependencies

### Core Technologies
- **React 18**: Frontend framework with modern hooks and concurrent features
- **Express**: Node.js web server framework
- **TypeScript**: Type safety across full stack
- **Tailwind CSS**: Utility-first CSS framework with custom terminal theme

### UI Framework
- **shadcn/ui**: Comprehensive React component library with Radix UI primitives
- **Radix UI**: Accessible component primitives (dialogs, menus, forms, etc.)
- **Lucide React**: Icon library for UI elements

### Development Tools
- **Vite**: Build tool and development server
- **ESBuild**: Fast JavaScript bundler for production
- **PostCSS**: CSS processing with Autoprefixer

### Database & ORM
- **Drizzle ORM**: Type-safe SQL toolkit with schema validation
- **Neon Database**: Serverless PostgreSQL database service
- **Drizzle Kit**: Migration and schema management tools

### Additional Libraries
- **React Query**: Server state management for API interactions
- **React Hook Form**: Form handling with validation
- **Zod**: Schema validation and type inference
- **Date-fns**: Date utility library
- **Class Variance Authority**: Utility for component variant management
- **Wouter**: Lightweight routing library

### Development Experience
- **Replit Integration**: Custom plugins for development environment
- **Hot Module Replacement**: Fast development feedback via Vite
- **TypeScript Integration**: Full type checking and IDE support

The architecture supports a terminal-themed cybersecurity portfolio with room for expansion into interactive security demonstrations, blog content, and enhanced user interactions while maintaining the authentic terminal aesthetic.