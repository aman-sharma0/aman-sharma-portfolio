import { useState } from 'react';
import ASCIILoader from '@/components/ASCIILoader';
import TerminalWindow from '@/components/TerminalWindow';

export default function Portfolio() {
  const [isLoading, setIsLoading] = useState(true);

  const handleLoadingComplete = () => {
    setIsLoading(false);
  };

  if (isLoading) {
    return <ASCIILoader onComplete={handleLoadingComplete} />;
  }

  return <TerminalWindow isLoading={false} />;
}