export const skillsData = [
  { name: 'Python', level: 90, category: 'Programming' },
  { name: 'Bash', level: 85, category: 'Programming' },
  { name: 'Metasploit', level: 85, category: 'Security Tools' },
  { name: 'Burp Suite', level: 80, category: 'Security Tools' },
  { name: 'Nmap', level: 95, category: 'Security Tools' },
  { name: 'Wireshark', level: 75, category: 'Security Tools' },
  { name: 'AWS Security', level: 70, category: 'Cloud Security' },
  { name: 'Penetration Testing', level: 85, category: 'Methodologies' },
  { name: 'VAPT', level: 90, category: 'Methodologies' },
  { name: 'Red Teaming', level: 75, category: 'Methodologies' }
];

export const certificationProgress = [
  { name: 'AWS Cloud Practitioner', status: 'completed', year: '2025' },
  { name: 'Cisco Cybersecurity Intro', status: 'completed', year: '2025' },
  { name: 'CEH (Certified Ethical Hacker)', status: 'in_progress', progress: 65 },
  { name: 'OSCP (Offensive Security)', status: 'planned', progress: 0 },
  { name: 'CRTP (Red Team Professional)', status: 'planned', progress: 0 }
];

export const portfolioData = {
  about: `Hi, I'm Aman Sharma
Cybersecurity Enthusiast & Penetration Testing Specialist

Currently working as an Associate Software Engineer at Tech Mahindra.

I am a passionate and ambitious Cybersecurity Enthusiast with expertise in:
• VAPT (Vulnerability Assessment & Penetration Testing)
• Networking & Infrastructure Security
• Cloud Security (AWS)
• Hardware Security Testing

MISSION: To become a top-tier Cybersecurity Professional, specializing in Red 
Teaming, Advanced Pentesting, and Hardware Security Testing while helping 
organizations secure their infrastructure against advanced threats.

Stats:
• 50+ Lab Machines Pwned
• 8 Professional Certifications
• Active on HackTheBox, TryHackMe, PortSwigger Academy`,

  skills: `Technical Arsenal - Comprehensive skillset spanning offensive security

PENETRATION TESTING:
• Web Application Testing (OWASP Top 10)
• Android App Pentesting  
• Infrastructure Testing
• Hardware Security Testing

SECURITY TOOLS:
• Metasploit Framework
• Burp Suite Professional
• Nmap & Network Discovery
• Wireshark & Traffic Analysis
• MobSF (Mobile Security)
• Frida (Dynamic Analysis)

CLOUD SECURITY:
• AWS Security Fundamentals
• Identity & Access Management
• Cloud Architecture Security

NETWORKING:
• TCP/IP, DNS, DHCP
• Firewalls & VPN Configuration
• Active Directory Security

PROGRAMMING:
[████████████████████████████████████████] Python 90%
[██████████████████████████████████████░░] Bash   85%
[████████████████████████████████████░░░░] SQL    80%

SECURITY TOOLS:
[██████████████████████████████████████░░] Metasploit 85%
[████████████████████████████████████░░░░] Burp Suite 80%
[████████████████████████████████████████] Nmap       95%
[██████████████████████████████████░░░░░░] Wireshark  75%

CLOUD SECURITY:
[██████████████████████████████░░░░░░░░░░] AWS Security 70%
[████████████████████████████████████░░░░] IAM          80%

PRACTICE PLATFORMS:
• HackTheBox - Active member
• TryHackMe - Regular contributor
• PortSwigger Academy - Web security
• VulnHub - Vulnerable VMs`,

  certifications: `Certifications & Achievements - Continuous learning in cybersecurity

RECENT ACHIEVEMENTS (2025):
✓ AWS Cloud Practitioner (CLF-C02) - [████████████████████] 100% COMPLETE
✓ Cisco Linux Unhatched - [████████████████████] 100% COMPLETE
✓ Cisco Cybersecurity Intro - [████████████████████] 100% COMPLETE

NUIX SPECIALIZATIONS:
✓ Data Discovery Core v9.10
✓ Data Discovery Admin v9.10
✓ Neo Investigations - Advanced
✓ Neo ID, Processing & Admin

UPCOMING CERTIFICATION GOALS:
→ CEH (Certified Ethical Hacker) - [█████████████░░░░░░░] 65% IN PROGRESS
→ OSCP (Offensive Security) - [░░░░░░░░░░░░░░░░░░░░] 0% PLANNED
→ CRTP (Red Team Professional) - [░░░░░░░░░░░░░░░░░░░░] 0% PLANNED

PRACTICE ACHIEVEMENTS:
• 50+ Lab Machines Successfully Compromised
• Active contributor on cybersecurity forums
• Regular participation in CTF competitions`,

  experience: `Professional Journey - Building expertise through hands-on experience

ASSOCIATE SOFTWARE ENGINEER
Tech Mahindra | Mar 2024 – Present
ENS – Digital Engineering Solutions

Key Responsibilities:
• Performing product security testing and vulnerability assessments
• Infrastructure security activities and hardening
• Collaborating with VAPT team to identify and report vulnerabilities
• Staying updated with emerging technologies and industry best practices

PARALLEL DEVELOPMENT:
• Active participation in penetration testing labs
• Red team exercise simulations and planning
• Continuous cybersecurity certification pursuit
• Network security research and testing

SPECIALIZED PROJECTS:

Web Application Security:
• Advanced penetration testing on PortSwigger Academy
• HackTheBox platform exploitation and documentation
• OWASP Top 10 vulnerability identification and remediation

Android Pentesting:
• Mobile application security analysis using MobSF
• Dynamic analysis with Frida framework
• Static and dynamic testing methodologies

Hardware Security:
• OS image analysis and forensics
• Root filesystem security testing on IoT devices
• Raspberry Pi and NVIDIA Orin security assessments`,

  contact: `Let's Connect - Ready to discuss cybersecurity opportunities

CONTACT INFORMATION:
Email: amansharma505152@gmail.com
LinkedIn: [LinkedIn Profile Available]
GitHub: [Active in cybersecurity repositories]

AREAS OF INTEREST:
• Red Team Operations & Advanced Penetration Testing
• Cloud Security Architecture & Implementation  
• Mobile Application Security & Reverse Engineering
• Hardware Security Testing & IoT Assessments
• Research Collaboration & Knowledge Sharing
• Mentorship in Cybersecurity Fundamentals

COLLABORATION OPPORTUNITIES:
• Security consulting projects
• Vulnerability research initiatives
• Open source security tool development
• Cybersecurity training and workshops
• Red team exercise participation

CURRENT FOCUS:
Actively seeking opportunities as:
→ Red Team Consultant
→ Senior Penetration Tester  
→ Cybersecurity Engineer
→ Security Researcher

Let's discuss how we can work together to strengthen cybersecurity defenses!`
};