import TerminalWindow from '../TerminalWindow';

export default function TerminalWindowExample() {
  return <TerminalWindow isLoading={false} />;
}