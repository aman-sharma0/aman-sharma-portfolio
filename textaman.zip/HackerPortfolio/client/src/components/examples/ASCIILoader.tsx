import ASCIILoader from '../ASCIILoader';

export default function ASCIILoaderExample() {
  return (
    <ASCIILoader onComplete={() => console.log('ASCII loading complete')} />
  );
}