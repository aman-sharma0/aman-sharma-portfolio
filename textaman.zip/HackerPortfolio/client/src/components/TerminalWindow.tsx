import { useState, useRef, useEffect } from 'react';
import { portfolioData, skillsData, certificationProgress } from '../data/portfolioData';

interface TerminalOutput {
  id: string;
  command: string;
  output: string;
  timestamp: Date;
}

interface TerminalWindowProps {
  isLoading?: boolean;
}

export default function TerminalWindow({ isLoading = false }: TerminalWindowProps) {
  const [input, setInput] = useState('');
  const [history, setHistory] = useState<TerminalOutput[]>([]);
  const [commandHistory, setCommandHistory] = useState<string[]>([]);
  const [historyIndex, setHistoryIndex] = useState(-1);
  const [sessionStart] = useState(new Date());
  const [isMobile, setIsMobile] = useState(false);
  const [isNearBottom, setIsNearBottom] = useState(true);
  const inputRef = useRef<HTMLInputElement>(null);
  const outputRef = useRef<HTMLDivElement>(null);

  const getProgressBars = () => {
    const bars = skillsData.map((skill, index) => 
      `${skill.name.padEnd(15)} [${'█'.repeat(Math.floor(skill.level/5))}${'░'.repeat(20-Math.floor(skill.level/5))}] ${skill.level}%`
    ).join('\n');
    return bars;
  };

  const getCertificationChart = () => {
    const certs = certificationProgress.map(cert => {
      if (cert.status === 'completed') {
        return `✓ ${cert.name} - [${'█'.repeat(20)}] COMPLETED (${cert.year})`;
      } else if (cert.status === 'in_progress') {
        const progress = cert.progress || 0;
        const filled = Math.floor((progress / 100) * 20);
        return `→ ${cert.name} - [${'█'.repeat(filled)}${'░'.repeat(20-filled)}] ${progress}% IN PROGRESS`;
      } else {
        return `○ ${cert.name} - [${'░'.repeat(20)}] PLANNED`;
      }
    }).join('\n');
    return certs;
  };

  const getSystemInfo = () => {
    const uptimeMs = Date.now() - sessionStart.getTime();
    const uptimeHours = Math.floor(uptimeMs / 3600000);
    const uptimeMinutes = Math.floor((uptimeMs % 3600000) / 60000);
    const uptimeSeconds = Math.floor((uptimeMs % 60000) / 1000);
    const uptimeStr = `${uptimeHours.toString().padStart(2, '0')}:${uptimeMinutes.toString().padStart(2, '0')}:${uptimeSeconds.toString().padStart(2, '0')}`;
    
    return `System Information:\n` +
           `OS: Kali Linux 2024.1\n` +
           `Kernel: 5.15.0-kali3-amd64\n` +
           `Uptime: ${uptimeStr}\n` +
           `CPU: Intel Core i7-12700K @ 3.60GHz\n` +
           `Memory: 32GB DDR4\n` +
           `Disk: 1TB NVMe SSD\n` +
           `Network: Ethernet + WiFi (Monitor Mode Capable)`;
  };

  const runNetworkScan = () => {
    return `Starting network reconnaissance...\n` +
           `\n[+] Target: textaman.com\n` +
           `[+] Scanning ports...\n` +
           `22/tcp   open  ssh     OpenSSH 8.9\n` +
           `80/tcp   open  http    nginx 1.20.1\n` +
           `443/tcp  open  https   nginx 1.20.1\n` +
           `\n[+] Service enumeration complete\n` +
           `[+] 3 services detected\n` +
           `[!] No vulnerabilities found - Secure configuration`;
  };

  const commands = {
    help: 'Available commands:\n\nPortfolio: about, skills, certs, experience, contact\nInteractive: skills-chart, cert-progress, sysinfo\nSecurity: nmap, sqlmap, hydra, netstat, ps\nSystem: ls, pwd, date, uname, whoami, clear, exit\n\nTip: Try "skills-chart" for interactive skill visualization!\n\n🌐 Normal GUI Website: https://www.textaman.com/',
    about: portfolioData.about,
    skills: portfolioData.skills,
    'skills-chart': getProgressBars(),
    'cert-progress': getCertificationChart(),
    certs: portfolioData.certifications,
    experience: portfolioData.experience,
    contact: portfolioData.contact,
    sysinfo: getSystemInfo(),
    clear: '',
    whoami: 'visitor@textaman:~$ cybersecurity_enthusiast',
    nmap: 'Nmap 7.94 ( https://nmap.org )\nUsage: nmap [Scan Type(s)] [Options] {target specification}\n\nTARGET SPECIFICATION:\n  Can pass hostnames, IP addresses, networks, etc.\n  Ex: scanme.nmap.org, microsoft.com/24, 192.168.1.1; 10.0.0-255.1-254\n\nHOST DISCOVERY:\n  -sL: List Scan - simply list targets to scan\n  -sn: Ping Scan - disable port scan\n  -Pn: Treat all hosts as online -- skip host discovery\n\nSCAN TECHNIQUES:\n  -sS/sT/sA/sW/sM: TCP SYN/Connect()/ACK/Window/Maimon scans\n  -sU: UDP Scan\n  -sN/sF/sX: TCP Null, FIN, and Xmas scans\n\nExample: nmap -v -A scanme.nmap.org',
    netstat: 'Active Internet connections\nProto Recv-Q Send-Q Local Address           Foreign Address         State\ntcp        0      0 0.0.0.0:22              0.0.0.0:*               LISTEN\ntcp        0      0 0.0.0.0:80              0.0.0.0:*               LISTEN\ntcp        0      0 0.0.0.0:443             0.0.0.0:*               LISTEN',
    sqlmap: 'sqlmap/1.7.11 - automatic SQL injection and database takeover tool\n\n[!] Legal disclaimer: Usage for attacking targets without consent is illegal\n\nUsage: python sqlmap.py [options]\n\nTarget options:\n  -u URL, --url=URL     Target URL\n  --data=DATA           Data string for POST requests\n  --cookie=COOKIE       HTTP Cookie header\n  --random-agent        Use random User-Agent headers\n\nDetection options:\n  --level=LEVEL         Level of tests (1-5, default 1)\n  --risk=RISK           Risk of tests (1-3, default 1)',
    hydra: 'Hydra v9.5 (c) 2023 by van Hauser/THC & David Maciejak\n\n[!] Legal disclaimer: Only use on systems you own or have permission to test\n\nSyntax: hydra [options] target service\n\nOptions:\n  -l LOGIN              Single username\n  -L FILE               Username list file\n  -p PASS               Single password\n  -P FILE               Password list file\n  -t TASKS              Number of parallel tasks (default: 16)\n  -f                    Exit after first found login/password pair',
    ps: 'USER       PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND\nroot         1  0.0  0.1 168164 13472 ?        Ss   08:00   0:01 /sbin/init\nroot         2  0.0  0.0      0     0 ?        S    08:00   0:00 [kthreadd]\nvisitor   1337  0.0  0.2  21532  8964 pts/0    Ss   08:01   0:00 -bash\nvisitor   1338  0.0  0.1  18592  3344 pts/0    S+   08:01   0:00 ./portfolio',
    exit: 'logout\nConnection to textaman.com closed.',
    ls: 'total 24K\n-rw-r--r-- 1 visitor visitor 4.2K Dec 11 08:01 about.txt\n-rw-r--r-- 1 visitor visitor 3.8K Dec 11 08:01 skills.txt\n-rw-r--r-- 1 visitor visitor 2.1K Dec 11 08:01 certs.txt\n-rw-r--r-- 1 visitor visitor 5.3K Dec 11 08:01 experience.txt\n-rw-r--r-- 1 visitor visitor 1.9K Dec 11 08:01 contact.txt\ndrwxr-xr-x 2 visitor visitor 4.0K Dec 11 08:01 tools/',
    'ls -la': 'total 32K\ndrwxr-xr-x 3 visitor visitor 4.0K Dec 11 08:01 .\ndrwxr-xr-x 5 root    root    4.0K Dec 10 20:15 ..\n-rw------- 1 visitor visitor  157 Dec 11 08:01 .bash_history\n-rw-r--r-- 1 visitor visitor  220 Dec 10 20:15 .bash_logout\n-rw-r--r-- 1 visitor visitor 3.7K Dec 10 20:15 .bashrc\n-rw-r--r-- 1 visitor visitor 4.2K Dec 11 08:01 about.txt\n-rw-r--r-- 1 visitor visitor 3.8K Dec 11 08:01 skills.txt\ndrwxr-xr-x 2 visitor visitor 4.0K Dec 11 08:01 tools/',
    pwd: '/home/visitor/portfolio',
    date: new Date().toLocaleString('en-US', { 
      weekday: 'short',
      month: 'short', 
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      timeZoneName: 'short',
      year: 'numeric'
    }),
    uname: 'Linux textaman 5.15.0-kali3-amd64 #1 SMP Debian 5.15.74-1kali2 x86_64 GNU/Linux',
    'uname -a': 'Linux textaman 5.15.0-kali3-amd64 #1 SMP Debian 5.15.74-1kali2 (2022-11-01) x86_64 GNU/Linux',
    cat: 'cat: missing file operand\nTry \'cat --help\' for more information.',
    'cat /etc/passwd': 'root:x:0:0:root:/root:/bin/bash\nvisitor:x:1000:1000:Visitor User,,,:/home/visitor:/bin/bash\nnobody:x:65534:65534:nobody:/nonexistent:/usr/sbin/nologin',
    history: commandHistory.slice(-10).map((cmd, i) => `${i + 1}  ${cmd}`).join('\n') || 'No command history',
    uptime: (() => {
      const uptimeMs = Date.now() - sessionStart.getTime();
      const uptimeHours = Math.floor(uptimeMs / 3600000);
      const uptimeMinutes = Math.floor((uptimeMs % 3600000) / 60000);
      return `${new Date().toLocaleTimeString()} up ${uptimeHours}:${uptimeMinutes.toString().padStart(2, '0')}, 1 user, load average: 0.15, 0.08, 0.05`;
    })()
  };

  const easterEggs = [
    'sudo rm -rf /',
    'rm -rf *',
    'dd if=/dev/zero of=/dev/sda',
    'format c:',
    ':(){ :|:& };:',
  ];

  // Mobile detection and scroll handling
  useEffect(() => {
    const checkIsMobile = () => {
      const userAgent = navigator.userAgent;
      const isMobileDevice = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(userAgent);
      const isSmallScreen = window.innerWidth < 768;
      setIsMobile(isMobileDevice || isSmallScreen);
    };

    checkIsMobile();
    window.addEventListener('resize', checkIsMobile);
    return () => window.removeEventListener('resize', checkIsMobile);
  }, []);

  useEffect(() => {
    if (outputRef.current && isNearBottom) {
      requestAnimationFrame(() => {
        if (outputRef.current) {
          outputRef.current.scrollTop = outputRef.current.scrollHeight;
        }
      });
    }
  }, [history, isNearBottom]);

  useEffect(() => {
    if (!isLoading && inputRef.current && !isMobile) {
      inputRef.current.focus();
    }
  }, [isLoading, isMobile]);

  const handleScroll = () => {
    if (outputRef.current) {
      const { scrollTop, scrollHeight, clientHeight } = outputRef.current;
      const isNearBottomThreshold = scrollHeight - scrollTop - clientHeight < 50;
      setIsNearBottom(isNearBottomThreshold);
    }
  };

  const scrollToBottom = () => {
    if (outputRef.current) {
      outputRef.current.scrollTo({
        top: outputRef.current.scrollHeight,
        behavior: 'smooth'
      });
    }
  };

  const handleTabCompletion = () => {
    const availableCommands = Object.keys(commands);
    const currentInput = input.toLowerCase();
    const matches = availableCommands.filter(cmd => cmd.startsWith(currentInput));
    
    if (matches.length === 1) {
      setInput(matches[0]);
    } else if (matches.length > 1) {
      const completionOutput: TerminalOutput = {
        id: Date.now().toString(),
        command: input,
        output: `Available completions:\n${matches.join('  ')}`,
        timestamp: new Date()
      };
      setHistory(prev => {
        const newHistory = [...prev, completionOutput];
        return newHistory.length > 200 ? newHistory.slice(-200) : newHistory;
      });
    }
  };

  const handleClearScreen = () => {
    setHistory([]);
  };

  const executeCommand = (cmd: string) => {
    const trimmedCmd = cmd.trim();
    const lowerCmd = trimmedCmd.toLowerCase();
    
    // Handle dangerous commands with warnings
    if (easterEggs.includes(lowerCmd)) {
      return '❌ Access denied. This is a portfolio demonstration, not a vulnerable system!\n\n[SECURITY WARNING] Destructive commands are not permitted.\nThis terminal is for portfolio exploration only.';
    }

    // Handle clear command
    if (lowerCmd === 'clear' || lowerCmd === 'cls') {
      setHistory([]);
      return '';
    }

    // Handle pipe simulation (basic)
    if (trimmedCmd.includes(' | ')) {
      const parts = trimmedCmd.split(' | ');
      const baseCmd = parts[0].trim().toLowerCase();
      const pipeCmd = parts[1].trim().toLowerCase();
      
      if (commands[baseCmd as keyof typeof commands]) {
        const output = commands[baseCmd as keyof typeof commands];
        if (pipeCmd.startsWith('grep ')) {
          const searchTerm = pipeCmd.replace('grep ', '').replace(/["']/g, '');
          const lines = output.split('\n').filter(line => 
            line.toLowerCase().includes(searchTerm.toLowerCase())
          );
          return lines.length > 0 ? lines.join('\n') : `grep: no matches found for '${searchTerm}'`;
        }
        if (pipeCmd === 'wc -l') {
          return `${output.split('\n').length}`;
        }
      }
    }

    // Handle command flags and variations
    if (commands[lowerCmd as keyof typeof commands]) {
      return commands[lowerCmd as keyof typeof commands];
    }

    // Handle cybersecurity commands with arguments
    if (lowerCmd.startsWith('nmap ')) {
      const target = lowerCmd.replace('nmap ', '');
      return `Starting Nmap 7.94 ( https://nmap.org ) at ${new Date().toLocaleTimeString()} UTC\nNmap scan report for ${target}\nHost is up (0.00050s latency).\nNot shown: 997 closed ports\nPORT     STATE SERVICE\n22/tcp   open  ssh\n80/tcp   open  http\n443/tcp  open  https\n\nNmap done: 1 IP address (1 host up) scanned in 0.12 seconds`;
    }

    if (lowerCmd.startsWith('sqlmap ')) {
      return `sqlmap/1.7.11 - automatic SQL injection and database takeover tool\n\n[!] Legal disclaimer: Usage for attacking targets without consent is illegal\n\n[*] Starting scan on provided URL...\n[*] Testing connection to target\n[*] Testing if target URL is stable\n[*] Target appears to be stable\n[*] Checking for SQL injection vulnerabilities\n[!] No SQL injection vulnerabilities found - Target appears secure`;
    }

    if (lowerCmd.startsWith('hydra ')) {
      return `Hydra v9.5 (c) 2023 by van Hauser/THC & David Maciejak\n\n[!] Legal disclaimer: Only use on systems you own or have permission to test\n\n[*] Hydra starting...\n[*] Protocol ssh supported, implementing RFC compliance\n[*] Trying login combinations\n[!] Attack stopped - No credentials found\n[!] Target appears to have strong authentication`;
    }

    // Handle some variations
    if (lowerCmd.startsWith('cat ')) {
      const file = lowerCmd.replace('cat ', '');
      if (file === 'about.txt') return portfolioData.about;
      if (file === 'skills.txt') return portfolioData.skills;
      if (file === 'certs.txt') return portfolioData.certifications;
      if (file === 'experience.txt') return portfolioData.experience;
      if (file === 'contact.txt') return portfolioData.contact;
      return `cat: ${file}: No such file or directory`;
    }

    if (lowerCmd.startsWith('echo ')) {
      return trimmedCmd.substring(5);
    }

    if (lowerCmd === 'tree') {
      return `/home/visitor/portfolio\n├── about.txt\n├── skills.txt\n├── certs.txt\n├── experience.txt\n├── contact.txt\n└── tools/\n    ├── nmap\n    ├── burpsuite\n    └── metasploit`;
    }

    // Unknown command
    return `bash: ${cmd}: command not found\n\nDid you mean one of these?\n  help     - Show available commands\n  skills   - View technical skills\n  about    - Learn about Aman Sharma\n  ls       - List files\n\nType 'help' for full command list.`;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    const output = executeCommand(input);
    
    const lowerInput = input.toLowerCase().trim();
    if (lowerInput !== 'clear' && lowerInput !== 'cls' && output !== '') {
      const newOutput: TerminalOutput = {
        id: Date.now().toString(),
        command: input,
        output,
        timestamp: new Date()
      };
      setHistory(prev => {
        const newHistory = [...prev, newOutput];
        // Cap history at 200 entries to prevent DOM bloat
        return newHistory.length > 200 ? newHistory.slice(-200) : newHistory;
      });
    }

    setCommandHistory(prev => [input, ...prev.slice(0, 49)]);
    setHistoryIndex(-1);
    setInput('');
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowUp') {
      e.preventDefault();
      if (historyIndex < commandHistory.length - 1) {
        const newIndex = historyIndex + 1;
        setHistoryIndex(newIndex);
        setInput(commandHistory[newIndex]);
      }
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      if (historyIndex > -1) {
        const newIndex = historyIndex - 1;
        setHistoryIndex(newIndex);
        setInput(newIndex === -1 ? '' : commandHistory[newIndex]);
      }
    } else if (e.key === 'Tab') {
      e.preventDefault();
      const availableCommands = Object.keys(commands);
      const currentInput = input.toLowerCase();
      const matches = availableCommands.filter(cmd => cmd.startsWith(currentInput));
      
      if (matches.length === 1) {
        setInput(matches[0]);
      } else if (matches.length > 1) {
        // Show available completions
        const completionOutput: TerminalOutput = {
          id: Date.now().toString(),
          command: input,
          output: `Available completions:\n${matches.join('  ')}`,
          timestamp: new Date()
        };
        setHistory(prev => {
          const newHistory = [...prev, completionOutput];
          // Cap history at 200 entries to prevent DOM bloat
          return newHistory.length > 200 ? newHistory.slice(-200) : newHistory;
        });
      }
    } else if (e.key === 'l' && e.ctrlKey) {
      // Ctrl+L to clear screen
      e.preventDefault();
      setHistory([]);
    }
  };

  if (isLoading) {
    return null;
  }

  return (
    <div className="min-h-[100dvh] md:h-screen text-white terminal-text flex flex-col overflow-x-hidden" style={{ backgroundColor: '#000000' }}>
      {/* Terminal Header - Sticky on mobile */}
      <div className="sticky top-0 z-50 border-b border-white px-3 sm:px-4 py-2 flex flex-col sm:flex-row items-center justify-between gap-2 sm:gap-0" style={{ backgroundColor: '#000000' }}>
        <div className="flex items-center justify-between w-full sm:w-auto">
          <div className="flex items-center space-x-1.5 sm:space-x-2">
            <div className="w-2.5 h-2.5 sm:w-3 sm:h-3 rounded-full bg-red-500"></div>
            <div className="w-2.5 h-2.5 sm:w-3 sm:h-3 rounded-full bg-yellow-500"></div>
            <div className="w-2.5 h-2.5 sm:w-3 sm:h-3 rounded-full bg-green-500"></div>
          </div>
          <div className="text-white text-xs sm:text-sm font-bold text-center flex-1 sm:flex-none">
            visitor@textaman:~/portfolio
          </div>
          <div className="text-white text-xs sm:text-sm hidden sm:block">
            {new Date().toLocaleTimeString()}
          </div>
        </div>
      </div>

      {/* Terminal Output */}
      <div 
        ref={outputRef}
        className="flex-1 overflow-auto p-3 sm:p-4 space-y-2 pb-[calc(env(safe-area-inset-bottom)+80px)] md:pb-4"
        data-testid="terminal-output"
        onScroll={handleScroll}
      >
        {/* Welcome Message - Responsive */}
        <div className="text-white mb-4 terminal-text">
          <div className="hidden sm:block">
            <div className="text-white font-semibold">┌─────────────────────────────────────────────────────────────┐</div>
            <div className="text-white">│ Welcome to textAman.com - Cybersecurity Portfolio Terminal │</div>
            <div className="text-white">│ Aman Sharma - Penetration Tester & Security Engineer       │</div>
            <div className="text-white">└─────────────────────────────────────────────────────────────┘</div>
          </div>
          <div className="block sm:hidden border border-white rounded p-2 text-[0.9em]">
            <div className="text-white font-semibold text-center">textAman.com</div>
            <div className="text-white text-center">Cybersecurity Portfolio</div>
            <div className="text-white text-center">Aman Sharma</div>
          </div>
          <div className="text-white mt-2">Last login: {new Date().toLocaleDateString()} on pts/0</div>
          <div className="text-white">Type 'help' for available commands | Try 'skills-chart' for interactive visuals</div>
          <div className="text-white">🌐 For normal GUI website: <a href="https://www.textaman.com/" target="_blank" rel="noopener noreferrer" className="text-green-400 hover:text-green-300 underline touch-target">https://www.textaman.com/</a></div>
        </div>

        {/* Command History */}
        {history.map((entry) => (
          <div key={entry.id} className="space-y-1">
            <div className="flex items-center space-x-2 terminal-text">
              <span className="text-white terminal-prompt">visitor@textaman:~$</span>
              <span className="text-white">{entry.command}</span>
            </div>
            {entry.output && (
              <div className="text-white whitespace-pre-wrap pl-4 terminal-text">
                {entry.output}
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Scroll to bottom button */}
      {!isNearBottom && (
        <button
          onClick={scrollToBottom}
          className="fixed right-4 z-60 bg-green-600 hover:bg-green-700 text-white px-3 py-1 rounded text-sm"
          style={{ bottom: 'calc(env(safe-area-inset-bottom) + 80px)' }}
          data-testid="scroll-to-bottom"
        >
          ↓ Scroll to bottom
        </button>
      )}

      {/* Terminal Input - Sticky on mobile */}
      <div className="sticky bottom-0 z-50 border-t border-white p-3 sm:p-4" style={{ backgroundColor: 'rgba(0,0,0,0.95)', paddingBottom: 'calc(env(safe-area-inset-bottom) + 12px)' }}>
        <div className="flex items-center space-x-2 sm:space-x-3">
          {/* Touch helper buttons for mobile */}
          {isMobile && (
            <div className="flex space-x-1">
              <button
                onClick={handleTabCompletion}
                className="text-xs bg-gray-700 hover:bg-gray-600 text-white px-2 py-1 rounded"
                data-testid="touch-tab"
              >
                Tab
              </button>
              <button
                onClick={handleClearScreen}
                className="text-xs bg-gray-700 hover:bg-gray-600 text-white px-2 py-1 rounded"
                data-testid="touch-clear"
              >
                Clear
              </button>
            </div>
          )}
        </div>
        <form onSubmit={handleSubmit} className="flex items-center space-x-2 terminal-text mt-2">
          <span className="text-white terminal-prompt text-sm sm:text-base">visitor@textaman:~$</span>
          <input
            ref={inputRef}
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            className="flex-1 bg-transparent border-none outline-none text-white caret-white terminal-input"
            placeholder=""
            data-testid="terminal-input"
            autoComplete="off"
            autoCapitalize="off"
            autoCorrect="off"
            spellCheck="false"
            inputMode="text"
          />
          <span className="terminal-cursor text-white">█</span>
        </form>
      </div>
    </div>
  );
}