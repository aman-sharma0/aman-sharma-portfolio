import { useState, useEffect } from 'react';

interface ASCIILoaderProps {
  onComplete: () => void;
}

export default function ASCIILoader({ onComplete }: ASCIILoaderProps) {
  const [currentLine, setCurrentLine] = useState(0);
  const [isComplete, setIsComplete] = useState(false);

  const asciiArt = [
    "┌────────────────────────────────────────────────────────────────────────┐",
    "│                                                                        │",
    "│ ████████ ████████ ██   ██ ████████  ██████  ██      ██  ██████  ██   ██│",
    "│    ██    ██        ██ ██     ██     ██    ██ ███    ███ ██    ██ ███  ██│",
    "│    ██    ████████   ███      ██     ████████ ████  ████ ████████ ████ ██│",
    "│    ██    ██        ██ ██     ██     ██    ██ ██ ████ ██ ██    ██ ██ ████│",
    "│    ██    ████████ ██   ██    ██     ██    ██ ██  ██  ██ ██    ██ ██  ███│",
    "│                                                                        │",
    "│                              .com                                     │",
    "│                                                                        │",
    "└────────────────────────────────────────────────────────────────────────┘",
    "",
    "Booting cybersecurity terminal...",
    "Loading security modules... [████████████████] 100%",
    "Establishing secure connection... OK",
    "Loading Aman Sharma's profile... OK",
    "Initializing penetration testing environment... OK",
    "",
    "Terminal ready. Type 'help' for available commands.",
    ""
  ];

  useEffect(() => {
    if (currentLine < asciiArt.length) {
      const timer = setTimeout(() => {
        setCurrentLine(currentLine + 1);
      }, 150);
      return () => clearTimeout(timer);
    } else if (!isComplete) {
      setIsComplete(true);
      setTimeout(() => {
        onComplete();
      }, 1000);
    }
  }, [currentLine, asciiArt.length, isComplete, onComplete]);

  return (
    <div className="h-screen text-white flex items-center justify-center p-4" style={{ backgroundColor: '#000000' }}>
      <div className="ascii-art max-w-4xl w-full">
        {asciiArt.slice(0, currentLine).map((line, index) => (
          <div key={index} className="whitespace-pre text-white">
            {line}
          </div>
        ))}
        {currentLine < asciiArt.length && (
          <span className="terminal-cursor text-white">█</span>
        )}
      </div>
    </div>
  );
}