# Design Guidelines: textAman Terminal Portfolio

## Design Approach
**Reference-Based Approach**: Inspired by authentic terminal interfaces (VS Code terminal, iTerm2, Windows Terminal) and cybersecurity tools aesthetic. The design prioritizes authenticity and immersion over conventional web patterns.

## Core Design Elements

### Color Palette
**Dark Mode Only** (matching terminal aesthetic):
- Background: `0 0% 0%` (pure black)
- Primary text: `0 0% 100%` (pure white)
- Secondary text: `120 100% 50%` (matrix green for prompts/commands)
- Accent: `60 100% 50%` (yellow for warnings/highlights)
- Error text: `0 100% 50%` (red for errors)
- Stars: `0 0% 80%` (slightly dimmed white, scattered randomly)

### Typography
- **Primary**: `'Fira Code', 'Monaco', 'Consolas', monospace` (terminal-authentic)
- **Fallback**: System monospace fonts
- **Sizes**: Consistent 14-16px base, maintaining terminal readability
- **Weight**: Regular (400) primarily, bold (700) for emphasis

### Layout System
**Terminal Grid Approach**:
- Use Tailwind spacing: `p-4, m-2, gap-1` (tight, terminal-like spacing)
- Full viewport height containers (`h-screen`)
- Fixed positioning for terminal window effect
- Responsive: Stack vertically on mobile while maintaining terminal feel

### Component Library

**Core Components**:
1. **ASCII Loading Screen**: Full-screen animated typewriter effect
2. **Terminal Window**: Fixed container with simulated window chrome
3. **Command Prompt**: Interactive input with blinking cursor
4. **Output Display**: Scrollable command results area
5. **Command History**: Up/down arrow navigation
6. **Auto-complete**: Tab completion suggestions

**Navigation Pattern**:
- Command-driven navigation (`about`, `skills`, `certs`, `experience`, `contact`)
- Help command (`help`, `--help`) for guidance
- Clear command (`clear`) to reset terminal
- Easter eggs (`whoami`, `ps aux`, `nmap`, `sqlmap --help`)

### Visual Effects
**Minimal Animations**:
- Typewriter effect for loading ASCII art and text output
- Blinking cursor animation
- Subtle star twinkling (very minimal, 2-3 second intervals)
- Terminal-style text scrolling

**Background Treatment**:
- Pure black background with randomly positioned white stars
- Stars as small dots (1-2px) scattered across viewport
- No gradients or modern web effects to maintain terminal authenticity

### Responsive Design
**Mobile Adaptations**:
- Maintain monospace font scaling
- Touch-friendly command buttons for common commands
- Swipe gestures for command history
- Preserve terminal aesthetic at all screen sizes
- Virtual keyboard considerations for command input

### Content Structure
**Single-Page Application**:
- Loading sequence with ASCII art
- Welcome message post-load
- Command-driven content revelation
- Portfolio information displayed as terminal output
- Contact form as terminal-style input prompts

### Key Design Principles
1. **Terminal Authenticity**: Every element should feel like a real terminal
2. **Cybersecurity Aesthetic**: References to security tools and commands
3. **Progressive Disclosure**: Content revealed through user commands
4. **Immersive Experience**: User feels like they're in a real terminal session
5. **Accessibility**: High contrast, keyboard navigation, screen reader friendly

### Images
**No Traditional Images**: The design relies entirely on ASCII art and text-based graphics to maintain terminal authenticity. The only visual elements are:
- ASCII art logo/loading screen (text-based)
- Scattered white star dots (CSS-generated)
- No hero images or traditional web graphics

This creates a unique, authentic cybersecurity professional aesthetic that stands out from conventional portfolio websites.